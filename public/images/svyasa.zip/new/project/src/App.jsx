import React, { useState } from "react";
import { Routes, Route, useNavigate } from "react-router-dom";
import Login from "./pages/login.jsx";
import ProtectedRoute from "./components/ProtectedRoute";
import Dashboard from "./pages/Dashboard/Dashboard";

const USERS = [
  {
    name: "Mahesh",
    usn: "9880",
    password: "123",
    role: "student",
    program: "MCA",
    semester: 2,
    dept: "CSE",

    // ⭐ UPDATED COURSE FORMAT (WORKS WITH YOUR UI)
    coursesBySem: {
      1: [
        {
          name: "Python Programming",
          code: "MCA101",
          faculty: "Mithun",
          credits: 4,
          type: "theory",
          units: ["Intro", "Syntax", "OOP", "Modules"]
        },
        {
          name: "C Programming",
          code: "MCA102",
          faculty: "Dr. Rao",
          credits: 4,
          type: "theory",
          units: ["Basics", "Pointers", "Structures"]
        }
      ],

      2: [
        {
          name: "Data Structures",
          code: "MCA201",
          faculty: "Mithun",
          credits: 4,
          type: "theory",
          units: ["Arrays", "Linked Lists", "Trees", "Graphs"]
        },
        {
          name: "Database Management",
          code: "MCA202",
          faculty: "Dr. Singh",
          credits: 4,
          type: "theory",
          units: ["ER", "SQL", "Normalization"]
        },
        {
          name: "Data Structures Lab",
          code: "MCA2L1",
          faculty: "Mithun",
          credits: 2,
          type: "lab",
          units: ["Lab 1", "Lab 2", "Lab 3"]
        }
      ],

      3: [
        {
          name: "Operating Systems",
          code: "MCA301",
          faculty: "Dr. Kumar",
          credits: 4,
          type: "theory",
          units: ["Processes", "Threads", "Memory"]
        },
        {
          name: "Operating Systems Lab",
          code: "MCA3L1",
          faculty: "Dr. Kumar",
          credits: 2,
          type: "lab",
          units: ["Lab Setup", "Scheduling Programs"]
        }
      ],

      4: [],
      5: [],
      6: []
    }
  },

  {
    name: "Mithun",
    usn: "7899",
    password: "123",
    role: "faculty",
    program: "MCA",
    semester: null,
    dept: "CSE",
    coursesBySem: {}
  }
];

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const navigate = useNavigate();

  const handleLogin = (usn, password, role) => {
    const user = USERS.find(
      (u) =>
        u.usn.toLowerCase() === usn.trim().toLowerCase() &&
        u.password === password &&
        u.role === role
    );
    if (!user) return { ok: false, message: "Invalid credentials" };
    setCurrentUser(user);
    return { ok: true };
  };

  const handleLogout = () => {
    setCurrentUser(null);
    navigate("/", { replace: true });
  };

  const handleUpdateUser = (updates) => {
    setCurrentUser((prev) => ({ ...prev, ...updates }));
  };

  return (
    <Routes>
      <Route path="/" element={<Login onLogin={handleLogin} />} />

      <Route
        path="/dashboard/*"
        element={
          <ProtectedRoute user={currentUser}>
            <Dashboard
              user={currentUser}
              onLogout={handleLogout}
              onUpdateUser={handleUpdateUser}
            />
          </ProtectedRoute>
        }
      />
    </Routes>
  );
}
