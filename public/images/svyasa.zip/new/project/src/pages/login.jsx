import React, { useState } from "react";
import { User, Lock } from "lucide-react";
import { useNavigate } from "react-router-dom";

export default function Login({ onLogin }) {
  const [usn, setUsn] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    const res = onLogin(usn, password, role);
    if (!res.ok) {
      setError(res.message || "Invalid login credentials.");
      return;
    }
    setError("");
    navigate("/dashboard/courses", { replace: true }); // default to courses
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-orange-50 relative">
      {/* Animated blobs */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute w-96 h-96 bg-orange-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob top-0 -left-4"></div>
        <div className="absolute w-96 h-96 bg-orange-300 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000 top-0 -right-4"></div>
        <div className="absolute w-96 h-96 bg-orange-400 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000 bottom-0 left-20"></div>
      </div>

      {/* Top nav */}
      <nav className="relative bg-gradient-to-r from-orange-600 via-orange-500 to-orange-600 shadow-xl">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-white p-2 rounded-lg shadow-lg">
                <User className="text-orange-600" size={28} />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">S-VYASA University</h1>
                <p className="text-orange-100 text-sm">Swami Vivekananda Yoga Anusandhana Samsthana</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-6 text-white">
              <a className="hover:text-orange-200">Home</a>
              <a className="hover:text-orange-200">About</a>
              <a className="hover:text-orange-200">Help</a>
              <a className="hover:text-orange-200">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      {/* main */}
      <div className="relative max-w-7xl mx-auto px-6 py-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 z-10">
            <h2 className="text-5xl font-bold text-gray-900 mb-4 leading-tight">
              Welcome to
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-orange-500">S-VYASA University</span>
            </h2>
            <p className="text-xl text-gray-600">Access your academic records, examination details, yoga courses and research materials all in one place.</p>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-orange-100">
                <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  <User className="text-orange-600" size={20} />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Course Access</h3>
                <p className="text-sm text-gray-600">View enrolled courses & materials</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-orange-100">
                <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  <User className="text-orange-600" size={20} />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Results</h3>
                <p className="text-sm text-gray-600">Check exam results</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-orange-100">
                <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  <User className="text-orange-600" size={20} />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Hall Tickets</h3>
                <p className="text-sm text-gray-600">Download hall tickets</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg border border-orange-100">
                <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  <User className="text-orange-600" size={20} />
                </div>
                <h3 className="font-bold text-gray-900 mb-2">Schedule</h3>
                <p className="text-sm text-gray-600">View class & exam schedules</p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-3xl shadow-2xl p-8 border border-orange-100">
            <div className="text-center mb-8">
              <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl shadow-lg mb-4">
                <User className="text-white" size={36} />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-2">Sign In</h2>
              <p className="text-gray-600">Choose your role to continue</p>
            </div>

            <div className="flex gap-2 mb-8 bg-gray-100 p-1 rounded-xl">
              {["student", "faculty", "admin"].map((r) => (
                <button
                  key={r}
                  onClick={() => setRole(r)}
                  className={`flex-1 py-3 rounded-lg font-semibold ${role === r ? "bg-gradient-to-r from-orange-500 to-orange-600 text-white" : "text-gray-600 hover:bg-white"}`}
                >
                  {r.toUpperCase()}
                </button>
              ))}
            </div>

            <form className="space-y-6" onSubmit={handleSubmit}>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">University Seat Number (USN)</label>
                <div className="relative">
                  <User className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input type="text" placeholder="Enter your USN" value={usn} onChange={(e) => setUsn(e.target.value)} className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-orange-500 outline-none" />
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Password</label>
                <div className="relative">
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={20} />
                  <input type="password" placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full pl-12 pr-4 py-3 border-2 border-gray-200 rounded-xl focus:border-orange-500 outline-none" />
                </div>
              </div>

              {error && <div className="text-red-500 text-sm">{error}</div>}

              <button type="submit" className="w-full bg-gradient-to-r from-orange-500 to-orange-600 text-white py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all">Sign In</button>
            </form>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="relative mt-20 bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <p className="text-gray-400">© 2024 S-VYASA Deemed to be University. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
