import React, { useEffect, useRef, useState } from "react";
import { Routes, Route, Link, useNavigate } from "react-router-dom";

import {
  GraduationCap,
  Menu,
  X,
  Home,
  BookOpen,
  FileText,
  Award,
  Calendar,
  ClipboardCheck,
  Settings,
  LogOut,
  Bell,
  Search,
} from "lucide-react";

import StudentCourses from "./StudentCourses";
import SubjectDetails from "./SubjectDetails";
import StudentExams from "./StudentExams";
import StudentResults from "./StudentResults";
import StudentSchedule from "./StudentSchedule";
import StudentAttendance from "./StudentAttendance";
import SettingsPage from "./SettingsPage";

export default function Dashboard({ user, onLogout, onUpdateUser }) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const notifRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handler = (e) => {
      if (showNotifications && notifRef.current && !notifRef.current.contains(e.target)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [showNotifications]);

  const notifications = [
    { id: 1, message: "Hall tickets available for Semester 5", time: "2 hours ago" },
    { id: 2, message: "IA marks updated for Data Structures", time: "1 day ago" },
    { id: 3, message: "Exam schedule published", time: "2 days ago" },
  ];

  return (
    <div className="flex h-screen bg-white relative overflow-hidden">

      {/* ========= SIDEBAR (UNCHANGED) ========= */}
      <div className="relative z-10 flex h-full">
        <aside
          className={`${sidebarOpen ? "w-72" : "w-20"}
          bg-white/80 backdrop-blur-xl shadow-xl border-r border-orange-200 
          transition-all duration-300 flex flex-col`}
        >
          <div className="p-4 flex items-center justify-between border-b border-orange-200">
            {sidebarOpen ? (
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-br from-orange-500 to-orange-600 p-2 rounded-xl shadow-md">
                  <GraduationCap className="text-white" size={24} />
                </div>
                <div>
                  <h2 className="font-bold text-gray-900">S-VYASA</h2>
                  <p className="text-xs text-gray-500">University</p>
                </div>
              </div>
            ) : (
              <GraduationCap className="text-orange-600" size={26} />
            )}

            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-orange-100 rounded-lg">
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>

          {/* Navigation */}
          <nav className="p-4 space-y-2">
            <SidebarLink to="courses" label={`My Courses`} icon={BookOpen} />
            <SidebarLink to="exams" label="Examinations" icon={FileText} />
              <SidebarLink to="attendance" label="Academics" icon={ClipboardCheck} />
            <SidebarLink to="schedule" label="Schedule" icon={Calendar} />
              <SidebarLink to="results" label="Support" icon={Award} />
          </nav>

          {/* ========= FIXED SETTINGS BUTTON ========= */}
          <div className="mt-auto p-4 border-t border-orange-200">
            <button
              onClick={() => navigate("/dashboard/settings")}
              className="w-full flex items-center gap-3 p-3 rounded hover:bg-orange-50"
            >
              <Settings /> <span>Settings</span>
            </button>

            <button
              onClick={() => {
                if (onLogout) onLogout();
                else window.location.href = "/";
              }}
              className="w-full mt-2 flex items-center gap-3 p-3 rounded text-red-600 hover:bg-red-50"
            >
              <LogOut /> <span>Logout</span>
            </button>
          </div>
        </aside>
      </div>

      {/* ========= MAIN CONTENT AREA ========= */}
      <div className="flex-1 flex flex-col bg-gradient-to-br from-orange-50 via-white to-orange-100">

        {/* Header */}
        <header className="bg-white/80 backdrop-blur-xl border-b border-orange-200 px-8 py-4 shadow-md flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Welcome, {user.name}</h1>
            <p className="text-sm text-gray-500">
              {user.usn} • {user.program} • Sem {user.semester}
            </p>
          </div>

          <div className="flex items-center gap-4">

            {/* Search */}
            <div className="relative">
              <input
                placeholder="Search…"
                className="pl-10 pr-4 py-2 border border-orange-300 rounded-xl w-64
                focus:border-orange-500 outline-none"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
            </div>

            {/* Notifications */}
            <div ref={notifRef} className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 rounded-xl hover:bg-orange-100 transition relative"
              >
                <Bell size={22} className="text-gray-700" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full"></span>
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-3 w-80 bg-white rounded-xl shadow-xl border border-orange-200 z-50">
                  <div className="p-4 border-b font-semibold">Notifications</div>
                  <div className="max-h-64 overflow-y-auto">
                    {notifications.map((n) => (
                      <div key={n.id} className="p-4 border-b hover:bg-orange-50 transition">
                        <p className="text-gray-900 text-sm mb-1">{n.message}</p>
                        <p className="text-xs text-gray-500">{n.time}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Profile */}
            <div className="flex items-center gap-3 pl-4 border-l border-orange-200">
              <img
                src={`https://ui-avatars.com/api/?name=${user.name}&background=ea580c&color=fff`}
                className="w-11 h-11 rounded-full shadow"
              />
              <div>
                <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                <p className="text-xs text-gray-500">{user.role.toUpperCase()}</p>
              </div>
            </div>
          </div>
        </header>

        {/* ========= ROUTES ========= */}
        <main className="flex-1 overflow-y-auto p-8">
          <Routes>
            <Route index element={<StudentCourses coursesBySem={user.coursesBySem} />} />
            <Route path="courses" element={<StudentCourses coursesBySem={user.coursesBySem} />} />
            <Route path="courses/:subjectId" element={<SubjectDetails coursesBySem={user.coursesBySem} />} />
            <Route path="exams" element={<StudentExams />} />
            <Route path="results" element={<StudentResults semester={user.semester} />} />
            <Route path="schedule" element={<StudentSchedule />} />
            <Route path="attendance" element={<StudentAttendance />} />
            <Route path="settings" element={<SettingsPage user={user} />} />
          </Routes>
        </main>

      </div>
    </div>
  );
}

/* Sidebar link helper (unchanged) */
function SidebarLink({ to, label, icon: Icon }) {
  return (
    <Link to={`/dashboard/${to}`} className="block">
      <button className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-orange-100 text-gray-700 transition">
        <Icon size={20} className="text-orange-600" />
        <span className="font-medium">{label}</span>
      </button>
    </Link>
  );
}
