import React, { useState } from "react";
import {
  User,
  GraduationCap,
  Lock,
  Settings,
  AlertCircle
} from "lucide-react";

export default function SettingsPage({ user }) {
  const [showAlert, setShowAlert] = useState(false);

  // show alert message
  const handleEditAttempt = () => {
    setShowAlert(true);
    setTimeout(() => setShowAlert(false), 2500);
  };

  // if user not loaded (rare, but safe)
  if (!user) {
    return (
      <div className="p-10 text-center text-gray-600 text-xl">
        Loading user details…
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto pb-20">

      {/* TOP TITLE */}
      <h1 className="text-4xl font-bold text-gray-900 mb-8">Settings</h1>

      {/* ALERT POPUP */}
      {showAlert && (
        <div className="mb-6 p-4 bg-orange-100 border border-orange-300 text-orange-800 rounded-xl flex items-center gap-3">
          <AlertCircle size={20} />
          <span>Only faculty can update student details.</span>
        </div>
      )}

      {/* ====================== PROFILE SETTINGS ====================== */}
      <div className="bg-white p-8 rounded-2xl shadow-md border border-orange-200 mb-8">

        <div className="flex items-center gap-4 mb-6">
          <User className="text-orange-600" size={28} />
          <h2 className="text-2xl font-semibold text-gray-900">
            Profile Information
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-6 text-gray-700">

          <DetailBox label="Full Name" value={user.name} />
          <DetailBox label="USN / Register Number" value={user.usn} />
          <DetailBox label="Program" value={user.program} />
          <DetailBox label="Department" value={user.dept} />
          <DetailBox label="Current Semester" value={user.semester} />
          <DetailBox label="Role" value={user.role.toUpperCase()} />

        </div>

        <div className="mt-6">
          <button
            onClick={handleEditAttempt}
            className="px-5 py-2 rounded-xl bg-orange-600 text-white font-semibold shadow hover:bg-orange-700 transition"
          >
            Request Profile Change
          </button>
        </div>
      </div>

      {/* ====================== ACADEMIC SETTINGS ====================== */}
      <div className="bg-white p-8 rounded-2xl shadow-md border border-orange-200 mb-8">

        <div className="flex items-center gap-4 mb-6">
          <GraduationCap className="text-orange-600" size={28} />
          <h2 className="text-2xl font-semibold text-gray-900">
            Academic Settings
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-6 text-gray-700">
          <DetailBox label="Program" value={user.program} />
          <DetailBox label="Semester" value={user.semester} />

          <div className="col-span-2 mt-3">
            <button
              onClick={handleEditAttempt}
              className="px-5 py-2 rounded-xl border border-orange-500 text-orange-600 font-semibold hover:bg-orange-50 transition"
            >
              Request Academic Update
            </button>
          </div>
        </div>

      </div>

      {/* ====================== PRIVACY & SECURITY ====================== */}
      <div className="bg-white p-8 rounded-2xl shadow-md border border-orange-200 mb-8">

        <div className="flex items-center gap-4 mb-6">
          <Lock className="text-orange-600" size={28} />
          <h2 className="text-2xl font-semibold text-gray-900">
            Privacy & Security
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-6">

          <ButtonBox title="Linked Devices" />
          <ButtonBox title="Two-step Verification" />
          <ButtonBox title="Login History" />

        </div>
      </div>

      {/* ====================== SYSTEM PREFERENCES ====================== */}
      <div className="bg-white p-8 rounded-2xl shadow-md border border-orange-200">

        <div className="flex items-center gap-4 mb-6">
          <Settings className="text-orange-600" size={28} />
          <h2 className="text-2xl font-semibold text-gray-900">
            System Preferences
          </h2>
        </div>

        <div className="grid grid-cols-2 gap-6">

          <ButtonBox title="Data Backup" />
          <ButtonBox title="Reset Preferences" />
          <ButtonBox title="Logout from All Devices" />

        </div>
      </div>

    </div>
  );
}

/* ====================== REUSABLE COMPONENTS ====================== */

function DetailBox({ label, value }) {
  return (
    <div className="bg-orange-50 p-4 rounded-xl border border-orange-200">
      <p className="text-xs text-gray-500">{label}</p>
      <p className="text-lg font-semibold text-gray-800">{value}</p>
    </div>
  );
}

function ButtonBox({ title }) {
  return (
    <button className="p-4 rounded-xl border border-gray-200 hover:bg-orange-50 transition text-gray-700 text-left">
      {title}
    </button>
  );
}
