import React from "react";
import {
  NotebookPen,
  FileCheck2,
  ClipboardList,
  CalendarDays,
} from "lucide-react";

/* SAMPLE DATA */
const scheduleItems = [
  // Assignments
  { id: 1, title: "Python Project Submission", date: "2025-11-16", type: "assignment" },
  { id: 2, title: "Java OOP Assignment", date: "2025-11-20", type: "assignment" },
  { id: 3, title: "DBMS ER Diagram Assignment", date: "2025-11-25", type: "assignment" },

  // IA Tests
  { id: 4, title: "IA Test: Data Structures", date: "2025-11-18", type: "ia" },
  { id: 5, title: "IA Test: Operating Systems", date: "2025-11-23", type: "ia" },

  // Tests / Quizzes
  { id: 6, title: "Quiz: DBMS", date: "2025-11-22", type: "test" },
  { id: 7, title: "Class Test: C Programming", date: "2025-11-27", type: "test" },
  { id: 8, title: "Mini Quiz: Java", date: "2025-11-29", type: "test" },
];

/* Get weekday name */
function dayName(iso) {
  return new Date(iso).toLocaleDateString(undefined, { weekday: "short" });
}

/* Styling per category */
const typeStyles = {
  assignment: {
    bg: "bg-blue-100",
    border: "border-blue-300",
    icon: <NotebookPen size={28} className="text-blue-600" />,
  },
  ia: {
    bg: "bg-green-100",
    border: "border-green-300",
    icon: <FileCheck2 size={28} className="text-green-600" />,
  },
  test: {
    bg: "bg-orange-100",
    border: "border-orange-300",
    icon: <ClipboardList size={28} className="text-orange-600" />,
  },
};

export default function StudentSchedule() {
  const assignments = scheduleItems.filter((s) => s.type === "assignment");
  const iaTests = scheduleItems.filter((s) => s.type === "ia");
  const quizzes = scheduleItems.filter((s) => s.type === "test");

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">

      <h2 className="text-2xl font-bold mb-6 text-gray-800 flex items-center gap-2">
        <CalendarDays className="text-orange-600" /> Schedule & Assignments
      </h2>

      {/* ================= ASSIGNMENTS SECTION ================= */}
      <Section title="Assignments" items={assignments} />

      {/* ================= IA TESTS SECTION ================= */}
      <Section title="IA Tests" items={iaTests} />

      {/* ================= QUIZZES / TESTS SECTION ================= */}
      <Section title="Quizzes & Tests" items={quizzes} />
    </div>
  );
}

/* SECTION COMPONENT */
function Section({ title, items }) {
  return (
    <div className="mb-10">
      <h3 className="text-xl font-semibold text-gray-700 mb-4">{title}</h3>

      {items.length === 0 ? (
        <div className="text-gray-500 text-sm">No items available.</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {items.map((s) => {
            const style = typeStyles[s.type];

            return (
              <div
                key={s.id}
                className={`
                  p-5 rounded-2xl shadow-sm border ${style.border} ${style.bg}
                  flex items-center gap-4 hover:shadow-xl 
                  hover:scale-[1.02] transition-all duration-300 cursor-pointer
                `}
              >
                {/* Icon Box */}
                <div className="p-3 bg-white rounded-xl shadow">
                  {style.icon}
                </div>

                {/* Main Content */}
                <div className="flex-1">
                  <div className="font-semibold text-gray-800 text-lg">{s.title}</div>
                  <div className="text-sm text-gray-600 mt-1">
                    {s.date} • {dayName(s.date)}
                  </div>
                </div>

                {/* Type Badge */}
                <div className="px-3 py-1 rounded-full text-xs font-semibold bg-white border shadow-sm">
                  {s.type.toUpperCase()}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
