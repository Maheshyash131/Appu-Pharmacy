import React, { useState } from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export default function StudentCourses({ coursesBySem }) {
  const semKeys = Object.keys(coursesBySem || {});

  const [selectedSem, setSelectedSem] = useState(semKeys[0] || "");

  const courses = coursesBySem[selectedSem] || [];

  // SAFE summary calculations
  const totalCredits = courses.reduce(
    (a, c) => a + (c?.credits || 0),
    0
  );

  const labCredits = courses
    .filter((c) => c?.type === "lab")
    .reduce((a, c) => a + (c?.credits || 0), 0);

  return (
    <div className="max-w-7xl mx-auto">

      <h1 className="text-4xl font-bold text-gray-900 mb-2">Course Overview</h1>
      <p className="text-gray-600 mb-6">
        View your semester subjects and academic progress.
      </p>

      {/* SELECT SEMESTER */}
      <div className="mb-6">
        <select
          value={selectedSem}
          onChange={(e) => setSelectedSem(e.target.value)}
          className="border border-orange-300 p-3 rounded-xl bg-white shadow-sm text-gray-700"
        >
          {semKeys.map((sem) => (
            <option key={sem} value={sem}>
              Semester {sem}
            </option>
          ))}
        </select>
      </div>

      {/* SUMMARY CARDS */}
      <div className="grid grid-cols-3 gap-4 mb-8">
        <SummaryCard title="Subjects" value={courses.length} />
        <SummaryCard title="Credits" value={totalCredits} />
        <SummaryCard title="Lab Credits" value={labCredits} />
      </div>

      {/* COURSE CARDS */}
      <div className="grid grid-cols-2 gap-6">
        {courses.map((subj, index) => (
          <div
            key={index}
            className="bg-white rounded-2xl p-6 shadow border border-orange-200 hover:shadow-lg transition"
          >
            <h2 className="text-xl font-bold text-gray-900 mb-1">
              {subj?.name || "Unnamed Subject"}
            </h2>

            <p className="text-gray-500 text-sm mb-2">{subj?.code || "N/A"}</p>

            <div className="mt-3 text-sm text-gray-700">
              <p><span className="font-semibold">Faculty:</span> {subj?.faculty || "N/A"}</p>
              <p><span className="font-semibold">Credits:</span> {subj?.credits || 0}</p>
              <p><span className="font-semibold">Type:</span> {subj?.type || "Theory"}</p>
              <p><span className="font-semibold">Attendance:</span> {subj?.attendance || 80}%</p>
            </div>

            {/* PROGRESS BAR */}
            <div className="mt-3">
              <div className="w-full bg-orange-100 rounded-full h-2">
                <div
                  className="bg-orange-500 h-2 rounded-full"
                  style={{ width: `${subj?.attendance || 80}%` }}
                ></div>
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <Link
                to={`/dashboard/courses/${subj?.code || index}`}
                className="flex-1 px-4 py-2 border border-orange-500 text-orange-600 rounded-xl font-semibold hover:bg-orange-50 transition text-center"
              >
                View Details
              </Link>

              <button className="flex items-center justify-center px-4 py-2 border rounded-xl border-gray-300 hover:bg-gray-100 transition">
                Notes <ChevronRight size={16} className="ml-2" />
              </button>
            </div>
          </div>
        ))}
      </div>

    </div>
  );
}

function SummaryCard({ title, value }) {
  return (
    <div className="bg-white p-5 rounded-xl shadow border border-orange-200 text-center">
      <h2 className="text-3xl font-bold text-orange-600">{value}</h2>
      <p className="text-gray-600">{title}</p>
    </div>
  );
}
