import React, { useState } from "react";
import {
  ClipboardCheck,
  CalendarDays,
  IdCard,
  Award,
  BarChart2,
  CheckCircle,
  ArrowLeft,
} from "lucide-react";

export default function StudentExams() {
  const [activePage, setActivePage] = useState("home");
  const [popupMessage, setPopupMessage] = useState("");
  const [showPopup, setShowPopup] = useState(false);

  const openPopup = (msg) => {
    setPopupMessage(msg);
    setShowPopup(true);
  };

  return (
    <div className="max-h-screen mt-14 w-full p-8 bg-[#F7F4EF] rounded-xl">

      {/* POPUP */}
      {showPopup && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-xl w-96 text-center">
            <h3 className="text-lg font-bold text-gray-800 mb-4">Success</h3>
            <p className="text-gray-600 mb-6">{popupMessage}</p>
            <button
              onClick={() => setShowPopup(false)}
              className="px-6 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* HEADER */}
      <h2 className="text-xl font-bold text-center text-gray-600 mb-10">
        {activePage === "home" ? "EXAM SECTION" : activePage.toUpperCase()}
      </h2>

      {activePage !== "home" && (
        <button
          onClick={() => setActivePage("home")}
          className="mb-6 flex items-center gap-2 text-orange-600 font-semibold"
        >
          <ArrowLeft size={20} /> Back
        </button>
      )}

      {/* EXAM MENU */}
      {activePage === "home" && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
          <ExamTile icon={<CheckCircle size={48} className="text-[#ea5905]" />} title="Exam Application" onClick={() => setActivePage("application")} />
          <ExamTile icon={<CalendarDays size={48} className="text-[#ea5905]" />} title="Exam Timetable" onClick={() => setActivePage("timetable")} />
          <ExamTile icon={<IdCard size={48} className="text-[#ea5905]" />} title="Hall Ticket" onClick={() => setActivePage("hallticket")} />
          <ExamTile icon={<Award size={48} className="text-[#ea5905]" />} title="Eligibility" onClick={() => setActivePage("eligibility")} />
          <ExamTile icon={<BarChart2 size={48} className="text-[#ea5905]" />} title="Revaluation" onClick={() => setActivePage("revaluation")} />
          <ExamTile icon={<ClipboardCheck size={48} className="text-[#ea5905]" />} title="CGPA & Results" onClick={() => setActivePage("cgpa")} />
        </div>
      )}

      {/* PAGES */}
      {activePage === "application" && <ExamApplication openPopup={openPopup} />}
      {activePage === "timetable" && <ExamTimetable />}
      {activePage === "hallticket" && <HallTicketPage openPopup={openPopup} />}
      {activePage === "eligibility" && <EligibilityPage openPopup={openPopup} />}
      {activePage === "revaluation" && <RevaluationPage openPopup={openPopup} />}
      {activePage === "cgpa" && <CGPAResultsPage />}
    </div>
  );
}

/* TILE */
function ExamTile({ icon, title, onClick }) {
  return (
    <div
      onClick={onClick}
      className="bg-white w-full h-44 rounded-2xl shadow-sm flex flex-col items-center justify-center
                 hover:shadow-xl hover:scale-[1.03] transition-all duration-300 cursor-pointer"
    >
      <div className="mb-3">{icon}</div>
      <p className="text-[#2A3A4A] font-semibold text-lg">{title}</p>
    </div>
  );
}

/* APPLICATION */
function ExamApplication({ openPopup }) {
  const student = { name: "Mahesh", usn: "1AA21CS001", program: "BCA", sem: 5 };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h1 className="text-50px font-bold mb-6 text-black">Exam Application</h1>

      <div className="space-y-3 text-gray-700">
        <p><b>Name:</b> {student.name}</p>
        <p><b>USN:</b> {student.usn}</p>
        <p><b>Program:</b> {student.program}</p>
        <p><b>Semester:</b> {student.sem}</p>
      </div>

      <button className="mt-5 bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700">
        Update Details
      </button>

      <button
        onClick={() => openPopup("Your Exam Application has been submitted successfully.")}
        className="mt-5 ml-4 bg-orange-600 text-white px-5 py-2 rounded-lg hover:bg-orange-700"
      >
        Submit Application
      </button>
    </div>
  );
}

/* TIMETABLE */
function ExamTimetable() {
  const timetable = [
    { date: "12 Dec", day: "Monday", subject: "Data Structures", time: "9:30 AM" },
    { date: "15 Dec", day: "Thursday", subject: "DBMS", time: "9:30 AM" },
    { date: "18 Dec", day: "Sunday", subject: "Operating Systems", time: "9:30 AM" },
    { date: "21 Dec", day: "Wednesday", subject: "Computer Networks", time: "9:30 AM" },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold mb-6 text-gray-700">Exam Timetable</h3>

      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-orange-100">
            <th className="p-3">Date</th>
            <th className="p-3">Day</th>
            <th className="p-3">Subject</th>
            <th className="p-3">Time</th>
          </tr>
        </thead>
        <tbody>
          {timetable.map((t, index) => (
            <tr key={index} className="border-b hover:bg-orange-50">
              <td className="p-3">{t.date}</td>
              <td className="p-3">{t.day}</td>
              <td className="p-3">{t.subject}</td>
              <td className="p-3">{t.time}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/* HALL TICKET */
function HallTicketPage({ openPopup }) {
  const attendance = 82;
  const iaMarks = 44;

  const eligible = attendance >= 80 && iaMarks >= 40;

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold text-gray-700 mb-4">Hall Ticket</h3>

      <p><b>Attendance:</b> {attendance}%</p>
      <p><b>IA Marks:</b> {iaMarks}</p>

      {eligible ? (
        <button
          onClick={() => openPopup("Your Hall Ticket Application is Successfully Submitted.")}
          className="mt-5 bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700"
        >
          Download Hall Ticket
        </button>
      ) : (
        <p className="text-red-600 mt-4 font-semibold">
          ❌ Not Eligible (80% Attendance + Pass IA Required)
        </p>
      )}
    </div>
  );
}

/* ELIGIBILITY */
function EligibilityPage({ openPopup }) {
  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold mb-4 text-gray-700">Eligibility Check</h3>

      <ul className="text-gray-700 space-y-2">
        <li>✔ Minimum 80% Attendance</li>
        <li>✔ Pass IA (Minimum 40)</li>
        <li>✔ No Fee Dues</li>
      </ul>

      <button
        onClick={() => openPopup("You are Eligible for the Exam")}
        className="mt-5 bg-orange-600 text-white px-6 py-2 rounded-lg hover:bg-orange-700"
      >
        Check Eligibility
      </button>
    </div>
  );
}

/* REVALUATION */
function RevaluationPage({ openPopup }) {
  const [subject, setSubject] = useState("");
  const [reason, setReason] = useState("");

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold mb-4 text-gray-700">Revaluation Form</h3>

      <div className="space-y-4">

        <div>
          <label className="font-semibold">Subject</label>
          <input
            type="text"
            className="w-full mt-1 p-2 border rounded-lg"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
        </div>

        <div>
          <label className="font-semibold">Reason</label>
          <textarea
            className="w-full mt-1 p-2 border rounded-lg"
            rows="3"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
          ></textarea>
        </div>

        <button
          onClick={() => openPopup("Your Revaluation Request Has Been Submitted")}
          className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700"
        >
          Submit Request
        </button>
      </div>
    </div>
  );
}

/* ========= DYNAMIC CGPA + RESULTS =========== */

const resultsBySemester = {
  1: [
    { subject: "Mathematics-I", ia1: 18, ia2: 17, sem: 78 },
    { subject: "C Programming", ia1: 19, ia2: 18, sem: 80 },
  ],
  2: [
    { subject: "Data Structures", ia1: 20, ia2: 19, sem: 85 },
    { subject: "Database Management", ia1: 18, ia2: 19, sem: 82 },
  ],
  3: [
    { subject: "DSA", ia1: 18, ia2: 17, sem: 79 },
  ],
  4: [
    { subject: "Java Programming", ia1: 19, ia2: 18, sem: 84 },
  ],
  5: [
    { subject: "Web Development", ia1: 20, ia2: 19, sem: null },
  ]
};

// Calculate SGPA dynamically
const calculateSGPA = (record) => {
  if (record.sem === null) return null;
  return ((record.ia1 + record.ia2 + record.sem) / 10).toFixed(2);
};

function CGPAResultsPage() {
  const maxSem = 6;

  // Determine last semester WITH a SEM result
  const completedSems = Object.keys(resultsBySemester).filter((sem) =>
    resultsBySemester[sem].some((r) => r.sem !== null)
  );

  const lastCompletedSem = Math.max(...completedSems);

  // Build SGPA list dynamically
  const sgpaList = [];

  for (let s = 1; s <= lastCompletedSem; s++) {
    const rows = resultsBySemester[s] || [];
    const valid = rows.filter((r) => r.sem !== null);

    if (valid.length > 0) {
      const avgSGPA =
        valid.reduce((sum, r) => sum + parseFloat(calculateSGPA(r)), 0) /
        valid.length;

      sgpaList.push({ sem: s, sgpa: avgSGPA.toFixed(2) });
    }
  }

  // Calculate CGPA from updated SGPA list
  const cgpa =
    sgpaList.reduce((sum, s) => sum + parseFloat(s.sgpa), 0) / sgpaList.length;

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h3 className="text-xl font-bold mb-6 text-gray-800">CGPA & Results</h3>

      {/* SGPA TABLE */}
      <table className="w-full mb-8 border-collapse">
        <thead>
          <tr className="bg-orange-100">
            <th className="p-3">Semester</th>
            <th className="p-3">SGPA</th>
          </tr>
        </thead>
        <tbody>
          {sgpaList.map((s) => (
            <tr key={s.sem} className="border-b hover:bg-orange-50">
              <td className="p-3">{s.sem}</td>
              <td className="p-3">{s.sgpa}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <p className="text-lg font-semibold mb-10">
        <b>Final CGPA:</b> {cgpa.toFixed(2)}
      </p>

      {/* RESULTS TABLE */}
      {Object.keys(resultsBySemester).map((sem) => {
        const rows = resultsBySemester[sem];

        return (
          <div key={sem} className="mb-6 bg-white rounded-lg p-4 shadow border">
            <div className="flex justify-between items-center mb-3">
              <div className="font-semibold text-gray-800">Semester {sem}</div>
              <div className="text-sm text-gray-500">
                {rows.some((r) => r.sem !== null)
                  ? "Result available"
                  : "Result not updated"}
              </div>
            </div>

            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-100 text-left text-xs text-gray-500">
                  <th className="pb-2 p-2">Subject</th>
                  <th className="pb-2 p-2">IA-1</th>
                  <th className="pb-2 p-2">IA-2</th>
                  <th className="pb-2 p-2">SEM</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={i} className="border-t">
                    <td className="py-2 p-2">{r.subject}</td>
                    <td className="py-2 p-2">{r.ia1 ?? "-"}</td>
                    <td className="py-2 p-2">{r.ia2 ?? "-"}</td>
                    <td className="py-2 p-2">
                      {r.sem === null ? (
                        <span className="text-orange-600">Result not updated</span>
                      ) : (
                        r.sem
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        );
      })}
    </div>
  );
}
