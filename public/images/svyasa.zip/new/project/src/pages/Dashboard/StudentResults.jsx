import React from "react";
import {
  HelpCircle,
  MessageCircle,
  FileText,
  PhoneCall,
  Search,
} from "lucide-react";

export default function Support() {
  return (
    <div className="p-8 bg-white rounded-xl shadow-sm">

      {/* PAGE TITLE */}
      <h1 className="text-4xl font-bold text-gray-900 mb-2">Support</h1>
      <p className="text-gray-500 mb-8">
        Search for support articles or contact us for help.
      </p>

      {/* SEARCH BAR */}
      <div className="relative mb-10">
        <input
          type="text"
          placeholder="Search support articles..."
          className="w-full border border-gray-300 rounded-xl py-3 pl-12 pr-4 focus:outline-none focus:border-orange-500"
        />
        <Search
          size={20}
          className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500"
        />
      </div>

      {/* SUPPORT OPTIONS GRID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10">

        {/* FAQ */}
        <SupportTile
          icon={<HelpCircle size={32} className="text-blue-600" />}
          title="Frequently Asked Questions"
          desc="Browse helpful articles and common questions"
        />

        {/* CONTACT SUPPORT */}
        <SupportTile
          icon={<PhoneCall size={32} className="text-green-600" />}
          title="Contact Support"
          desc="Chat with our team for additional help"
        />

        {/* REPORT ISSUE */}
        <SupportTile
          icon={<MessageCircle size={32} className="text-red-600" />}
          title="Report an Issue"
          desc="Found something wrong? Let us know"
        />

        {/* DOCUMENTATION */}
        <SupportTile
          icon={<FileText size={32} className="text-purple-600" />}
          title="Documentation"
          desc="Access guides, manuals, and help docs"
        />

      </div>

      {/* ACADEMIC TIMELINE */}
      <div className="bg-gray-50 border border-gray-200 p-5 rounded-xl">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Academic Timeline
        </h3>

        {/* PROGRESS BAR */}
        <div className="w-full bg-gray-200 rounded-full h-3 mb-4">
          <div
            className="h-3 rounded-full bg-blue-500"
            style={{ width: "65%" }}
          ></div>
        </div>

        {/* LABELS */}
        <div className="flex justify-between text-sm font-medium text-gray-600">
          <span>Lectures</span>
          <span>Assignments</span>
          <span>Exams</span>
          <span>Results</span>
        </div>
      </div>
    </div>
  );
}

/* SUPPORT TILE COMPONENT */
function SupportTile({ icon, title, desc }) {
  return (
    <div
      className="
        bg-white border border-gray-200 
        rounded-2xl p-6 shadow-sm 
        hover:shadow-lg hover:scale-[1.02]
        transition-all duration-300 cursor-pointer
      "
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-lg font-semibold text-gray-800 mb-1">{title}</h3>
      <p className="text-sm text-gray-500">{desc}</p>
    </div>
  );
}
