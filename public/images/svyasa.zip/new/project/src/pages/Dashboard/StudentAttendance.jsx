import React, { useState } from "react";
import {
  CheckSquare,
  ClipboardList,
  ClipboardCheck,
  FolderKanban,
  ArrowLeft,
} from "lucide-react";

export default function Academics() {
  const [activePage, setActivePage] = useState("home");

  return (
    <div className="max-h-screen mt-10 w-full p-8 bg-[#F7F4EF] rounded-xl">

      {/* Back Button */}
      {activePage !== "home" && (
        <button
          onClick={() => setActivePage("home")}
          className="mb-6 flex items-center gap-2 text-orange-600 font-semibold"
        >
          <ArrowLeft size={20} /> Back
        </button>
      )}

      {/* Heading */}
      <h2 className="text-2xl font-bold text-center text-gray-700 mb-10">
        {activePage === "home" ? "ACADEMICS" : activePage.toUpperCase()}
      </h2>

      {/* ========= MAIN GRID ========= */}
      {activePage === "home" && (
        <div className="grid grid-cols-2 md:grid-cols-2 gap-10 max-w-3xl mx-auto">

          {/* Attendance */}
          <AcademicsTile
            icon={<CheckSquare size={48} className="text-[#ea5905]" />}
            title="Attendance"
            onClick={() => setActivePage("attendance")}
          />

          {/* Project Section */}
          <AcademicsTile
            icon={<FolderKanban size={48} className="text-[#ea5905]" />}
            title="Projects"
            onClick={() => setActivePage("projects")}
          />

          {/* CIA 1 */}
          <AcademicsTile
            icon={<ClipboardList size={48} className="text-[#ea5905]" />}
            title="CIA 1"
            onClick={() => setActivePage("cia1")}
          />

          {/* CIA 2 */}
          <AcademicsTile
            icon={<ClipboardCheck size={48} className="text-[#ea5905]" />}
            title="CIA 2"
            onClick={() => setActivePage("cia2")}
          />

        </div>
      )}

      {/* Pages */}
      {activePage === "attendance" && <AttendanceSection />}
      {activePage === "projects" && <ProjectSection />}
      {activePage === "cia1" && <CIASection number={1} />}
      {activePage === "cia2" && <CIASection number={2} />}
    </div>
  );
}

/* =================== TILE COMPONENT =================== */
function AcademicsTile({ icon, title, onClick }) {
  return (
    <div
      onClick={onClick}
      className="
        bg-white w-full h-44 rounded-2xl shadow-sm
        flex flex-col items-center justify-center
        hover:shadow-xl hover:scale-[1.03]
        transition-all duration-300 cursor-pointer
      "
    >
      <div className="mb-4">{icon}</div>
      <p className="text-[#2A3A4A] font-semibold text-lg">{title}</p>
    </div>
  );
}

/* =================== ATTENDANCE SECTION =================== */
function AttendanceSection() {
  const attendanceData = [
    { subject: "Data Structures", attended: 42, total: 50 },
    { subject: "Operating Systems", attended: 38, total: 50 },
    { subject: "DBMS", attended: 44, total: 50 },
    { subject: "Web Programming", attended: 41, total: 50 },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold text-gray-700 mb-4">Attendance</h3>

      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-orange-100">
            <th className="p-3 text-left">Subject</th>
            <th className="p-3">Attended</th>
            <th className="p-3">Total</th>
            <th className="p-3">Percentage</th>
          </tr>
        </thead>
        <tbody>
          {attendanceData.map((a, i) => {
            const percent = Math.floor((a.attended / a.total) * 100);
            return (
              <tr key={i} className="border-b text-center">
                <td className="p-3 text-left">{a.subject}</td>
                <td>{a.attended}</td>
                <td>{a.total}</td>
                <td className="font-semibold">{percent}%</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

/* =================== PROJECT SECTION (UPDATED) =================== */
function ProjectSection() {
  const projects = [
    {
      subject: "Data Structures",
      title: "Binary Search Tree Visualizer",
      behavior: "Shows insertion, deletion, and traversal animations",
      projectMarks: 4,
      behaviorMarks: 5,
      status: "Completed",
    },
    {
      subject: "Operating Systems",
      title: "Process Scheduling Simulator",
      behavior: "Implements FCFS, Round Robin, and SJF",
      projectMarks: 3,
      behaviorMarks: 4,
      status: "In Progress",
    },
    {
      subject: "DBMS",
      title: "Library Management System",
      behavior: "Manages books, users, issuing, fines, and roles",
      projectMarks: 5,
      behaviorMarks: 5,
      status: "Completed",
    },
    {
      subject: "Web Programming",
      title: "Food Delivery App",
      behavior: "Real-time tracking, cart system, and login",
      projectMarks: 4,
      behaviorMarks: 3,
      status: "Pending",
    },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold text-gray-700 mb-4">Projects</h3>

      <div className="space-y-6">
        {projects.map((p, i) => {
          const total = p.projectMarks + p.behaviorMarks;

          return (
            <div
              key={i}
              className="border rounded-xl p-5 shadow-sm hover:shadow-md transition bg-white"
            >
              <h4 className="text-lg font-semibold text-gray-800">{p.subject}</h4>

              <p className="text-gray-700 mt-2">
                <b>Project:</b> {p.title}
              </p>

              <p className="text-gray-700 mt-1">
                <b>Behavior:</b> {p.behavior}
              </p>

              <div className="mt-3 grid grid-cols-3 gap-4 text-center">
                <div className="bg-orange-100 p-3 rounded-xl">
                  <p className="text-gray-700 font-semibold">Project Marks</p>
                  <p className="text-xl font-bold text-orange-600">{p.projectMarks}/5</p>
                </div>

                <div className="bg-orange-100 p-3 rounded-xl">
                  <p className="text-gray-700 font-semibold">Behavior Marks</p>
                  <p className="text-xl font-bold text-orange-600">{p.behaviorMarks}/5</p>
                </div>

                <div className="bg-orange-100 p-3 rounded-xl">
                  <p className="text-gray-700 font-semibold">Total</p>
                  <p className="text-xl font-bold text-green-700">{total}/10</p>
                </div>
              </div>

              <p className="mt-3 font-semibold text-orange-700">Status: {p.status}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* =================== CIA SECTION =================== */
function CIASection({ number }) {
  const ciaMarks = [
    { subject: "Data Structures", mark: 24 },
    { subject: "Operating Systems", mark: 22 },
    { subject: "DBMS", mark: 23 },
    { subject: "Web Programming", mark: 21 },
  ];

  return (
    <div className="bg-white p-6 rounded-xl shadow-md">
      <h3 className="text-xl font-bold text-gray-700 mb-4">CIA {number}</h3>

      <table className="w-full border-collapse">
        <thead>
          <tr className="bg-orange-100">
            <th className="p-3 text-left">Subject</th>
            <th className="p-3">Marks</th>
          </tr>
        </thead>
        <tbody>
          {ciaMarks.map((m, i) => (
            <tr key={i} className="border-b text-center">
              <td className="p-3 text-left">{m.subject}</td>
              <td>{m.mark}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
