import React, { useState } from "react";
import { useParams } from "react-router-dom";

/* helper to find subject by slug */
const slug = (s) => s.toLowerCase().replace(/\s+/g, "-").replace(/[^\w-]/g, "");

export default function SubjectDetails({ coursesBySem = {} }) {
  const { subjectId } = useParams();
  const all = Object.values(coursesBySem).flat();
  const subject = all.find((s) => slug(s.name) === subjectId);

  const [message, setMessage] = useState("");
  const [issueType, setIssueType] = useState("Wrong marks");
  const [sent, setSent] = useState(false);

  if (!subject) {
    return (
      <div className="bg-white p-6 rounded-xl shadow">
        <h2 className="text-lg font-semibold">Subject not found</h2>
        <p className="text-sm text-gray-500 mt-2">Go back to courses and select a valid subject.</p>
      </div>
    );
  }

  const submitReport = (e) => {
    e.preventDefault();
    // store locally (in real app you'd send to backend)
    console.log("Report submitted:", { subject: subject.name, issueType, message });
    setSent(true);
    setMessage("");
    setTimeout(() => setSent(false), 4000);
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-2xl font-bold">{subject.name}</h2>
          <div className="text-sm text-gray-500 mt-1">Faculty: {subject.faculty}</div>
          <div className="text-xs text-gray-400 mt-1">Units: {subject.units.length}</div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2">
          <h3 className="font-semibold mb-2">Units</h3>
          <ol className="list-decimal pl-6 space-y-2">
            {subject.units.map((u, i) => (
              <li key={i} className="text-gray-700">{u}</li>
            ))}
          </ol>
        </div>

        <div>
          <h3 className="font-semibold mb-2">Report Issue / Send Assessment</h3>

          <form onSubmit={submitReport} className="space-y-3">
            <div>
              <label className="text-sm text-gray-600">Type</label>
              <select value={issueType} onChange={(e)=>setIssueType(e.target.value)} className="w-full border p-2 rounded mt-1">
                <option>Wrong marks</option>
                <option>Attendance mismatch</option>
                <option>IA not updated</option>
                <option>Other</option>
              </select>
            </div>

            <div>
              <label className="text-sm text-gray-600">Message</label>
              <textarea value={message} onChange={(e)=>setMessage(e.target.value)} rows={5} className="w-full border p-2 rounded mt-1" placeholder="Describe the issue or assessment request..."></textarea>
            </div>

            <button type="submit" className="w-full bg-orange-600 text-white py-2 rounded">Send to Faculty</button>

            {sent && <div className="text-green-600 text-sm">Report sent successfully (local only).</div>}
          </form>
        </div>
      </div>
    </div>
  );
}
